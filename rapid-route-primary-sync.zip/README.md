# rapid-route-primary-sync

Copies every telemetry event from TimescaleDB into the **primary**
bus-enterprise database's `telemetry` schema.

**This repo only syncs data - it does not create the schema.** The
schema itself (`bus_enterprise_telemetry_schema.sql`) is a separate,
standalone file, delivered on its own so you can add it to your own
`init-sql` / migration process however fits your workflow. Apply that
file to `bus_enterprise` **before** running this service - `app.py`
checks for `telemetry.bus_events` on startup and waits/retries if it
isn't there yet, rather than creating it itself.

## Why this design

You said the primary DB is already running in production and can't be
changed. So:

- **No `ALTER TABLE`, ever**, in the schema file - only `CREATE SCHEMA
  IF NOT EXISTS`, `CREATE TABLE IF NOT EXISTS`, `CREATE OR REPLACE
  VIEW`. Every statement is additive and idempotent.
- **Schema and app are separate on purpose.** You apply the schema file
  through your own process (init-sql for fresh setups, a one-off `psql`
  run for the already-running instance - see that file's own header for
  both). This app never runs DDL against your database.
- **Polling, not another Kafka consumer.** The primary DB only ever
  talks to two Postgres databases (itself + TimescaleDB) - no Kafka
  client added to whatever's already running against it.
- **Best-effort vehicle linking, not a hard requirement.** `bus_id`
  values like `BUS-001` are demo identifiers, not real plates, so most
  won't match a row in `core.vehicles`. Events still sync either way -
  `telemetry.bus_events.vehicle_id` is just `NULL` when nothing matches.

## What the schema file creates (once, additively) in the primary DB

```sql
CREATE SCHEMA telemetry;

telemetry.buses          -- bus_id <-> core.vehicles(id) mapping (vehicle_id nullable)
telemetry.bus_events     -- (time, bus_id, vehicle_id, event_type, payload jsonb)
telemetry.sync_state     -- single-row watermark, so restarts resume correctly
telemetry.v_latest_bus_status  -- view: latest event per bus, joined to vehicle info
```

See `bus_enterprise_telemetry_schema.sql` for the exact DDL and how to
apply it - read it before running against a real production database,
same as you would for any migration.

## Vehicle matching rule

`resolve_vehicle_id()` in `app.py` currently matches
`upper(bus_id) = upper(core.vehicles.registration_number)`. Once you
share how your real buses' `bus_id` values relate to
`registration_number` (same format? a separate mapping table? a prefix
scheme?), this is the one function to adjust.

## Connection details

Now wired up against the real `bus_enterprise_db` compose setup:

| | |
|---|---|
| Network | `bus_enterprise_net` (this repo joins it directly, as `docker-compose.yml`'s own comment there suggests) |
| Host (from this container) | `bus_db` (the service name - resolves via Docker's embedded DNS since both are on `bus_enterprise_net`) |
| Database | `bus_enterprise` |
| User | `postgres` |
| Password | `dev_password_only` - the `docker-compose.override.yml` dev value, active on a plain local `docker compose up` |

**Production note**: the override file's plaintext password is a local
dev convenience. In any environment where that override isn't applied
(a real deployment using the base `docker-compose.yml`'s
`POSTGRES_PASSWORD_FILE`/`secrets` setup), override `PRIMARY_DSN` here
(or via `.env`) with the real credentials - never commit real
credentials into this file.

Direct network join (not `host.docker.internal`) was used here on
purpose - this machine has repeatedly hit flaky `host.docker.internal`
TCP behavior on Windows/Docker Desktop (see `rapid-route-timescale-sink`'s
history), and `bus_db`'s own compose file already documents this same
join-the-network pattern for other backend repos.

## Run

**First**, apply `bus_enterprise_telemetry_schema.sql` to `bus_enterprise`
(see that file's header for exact commands) - this only needs doing
once.

### With Docker

Needs `rapid-route-timescaledb` (creates `rapid-route-shared`) and the
primary DB (`bus_db` - creates `bus_enterprise_net`) both running first:

```bash
docker compose up --build
```

### Without Docker

```bash
pip install -r requirements.txt
export TIMESCALE_DSN=postgresql://rapidroute:rapidroute@localhost:5432/bus_telemetry
export PRIMARY_DSN=postgresql://postgres:dev_password_only@localhost:5433/bus_enterprise
python app.py
```

## Offline Docker builds

Same pattern as the other repos:

```powershell
pip download -r requirements.txt -d wheels `
    --platform manylinux_2_28_x86_64 --platform manylinux2014_x86_64 `
    --python-version 311 --implementation cp --abi cp311 `
    --only-binary=:all:
```

## Checking it worked

```sql
SELECT * FROM telemetry.v_latest_bus_status;
SELECT bus_id, vehicle_id, count(*) FROM telemetry.bus_events GROUP BY bus_id, vehicle_id;
```
