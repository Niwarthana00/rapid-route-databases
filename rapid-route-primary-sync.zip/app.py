"""
TimescaleDB -> Primary DB sync
-------------------------------
Repo: rapid-route-primary-sync

Periodically reads new rows from TimescaleDB's bus_telemetry_events
(rapid-route-timescaledb + rapid-route-timescale-sink) and copies them
into the PRIMARY bus-enterprise database, into its `telemetry` schema -
never touching the existing core/biz/fin/system schemas or their tables
in any way.

This service does NOT create that schema itself - it expects
telemetry.buses, telemetry.bus_events, and telemetry.sync_state to
already exist in bus_enterprise (see bus_enterprise_telemetry_schema.sql,
delivered separately - apply that to bus_db once, however fits your own
migration process, before running this).

Why poll TimescaleDB instead of consuming Kafka again: this keeps the
primary DB fully decoupled from Kafka - it only ever talks to two
Postgres-family databases, which is an easier thing to run in an
already-live production environment than adding a Kafka client to it.

Bus -> vehicle linking: bus_id values like "BUS-001" won't usually match
a real registration_number, so the match in resolve_vehicle_id() below
is best-effort - unmatched buses still get a telemetry.buses row (with
vehicle_id NULL) and their events still sync, just without an enterprise
vehicle link. Adjust the matching rule there once you know your real
bus_id <-> registration_number scheme.

Run:
    pip install -r requirements.txt
    TIMESCALE_DSN=postgresql://rapidroute:rapidroute@localhost:5432/bus_telemetry \\
    PRIMARY_DSN=postgresql://postgres:dev_password_only@localhost:5433/bus_enterprise \\
    python app.py
"""
import logging
import os
import time as time_module

import psycopg2
import psycopg2.extras

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("primary-sync")

TIMESCALE_DSN = os.environ.get(
    "TIMESCALE_DSN",
    "postgresql://rapidroute:rapidroute@timescaledb:5432/bus_telemetry",
)
# TODO: production credentials come from bus_db's real secrets (not this
# default) - this default matches the docker-compose.override.yml dev
# password, which is what's active on a plain local `docker compose up`.
PRIMARY_DSN = os.environ.get(
    "PRIMARY_DSN",
    "postgresql://postgres:dev_password_only@bus_db:5432/bus_enterprise",
)
POLL_INTERVAL_SECONDS = int(os.environ.get("POLL_INTERVAL_SECONDS", "5"))
BATCH_SIZE = int(os.environ.get("BATCH_SIZE", "500"))


def connect(dsn: str, label: str):
    while True:
        try:
            conn = psycopg2.connect(dsn)
            conn.autocommit = True
            log.info("Connected to %s", label)
            return conn
        except Exception as exc:
            log.warning("%s connect failed (%s) - retrying in 5s", label, exc)
            time_module.sleep(5)


def check_schema_exists(primary_cur) -> bool:
    primary_cur.execute(
        "SELECT to_regclass('telemetry.bus_events') IS NOT NULL"
    )
    return primary_cur.fetchone()[0]


_vehicle_id_cache: dict = {}


def resolve_vehicle_id(primary_cur, bus_id: str):
    """Best-effort match of our bus_id to a real vehicle via
    registration_number. Returns None (not an error) when nothing
    matches - most demo bus_id values won't match a real plate."""
    if bus_id in _vehicle_id_cache:
        return _vehicle_id_cache[bus_id]

    primary_cur.execute(
        "SELECT id FROM core.vehicles WHERE upper(registration_number) = upper(%s) LIMIT 1",
        (bus_id,),
    )
    row = primary_cur.fetchone()
    vehicle_id = row[0] if row else None
    _vehicle_id_cache[bus_id] = vehicle_id
    return vehicle_id


def ensure_bus_row(primary_cur, bus_id: str, vehicle_id) -> None:
    primary_cur.execute(
        """
        INSERT INTO telemetry.buses (bus_id, vehicle_id, first_seen, last_seen)
        VALUES (%s, %s, now(), now())
        ON CONFLICT (bus_id) DO UPDATE SET
            last_seen = now(),
            vehicle_id = COALESCE(telemetry.buses.vehicle_id, EXCLUDED.vehicle_id)
        """,
        (bus_id, vehicle_id),
    )


def get_watermark(primary_cur):
    primary_cur.execute("SELECT last_synced_time FROM telemetry.sync_state WHERE id = TRUE")
    return primary_cur.fetchone()[0]


def set_watermark(primary_cur, ts) -> None:
    primary_cur.execute(
        "UPDATE telemetry.sync_state SET last_synced_time = %s WHERE id = TRUE", (ts,)
    )


def sync_once(timescale_cur, primary_cur) -> int:
    watermark = get_watermark(primary_cur)

    timescale_cur.execute(
        """
        SELECT time, bus_id, event_type, payload
        FROM bus_telemetry_events
        WHERE time > %s
        ORDER BY time
        LIMIT %s
        """,
        (watermark, BATCH_SIZE),
    )
    rows = timescale_cur.fetchall()
    if not rows:
        return 0

    latest_time = watermark
    for row in rows:
        ts, bus_id, event_type, payload = row
        vehicle_id = resolve_vehicle_id(primary_cur, bus_id)
        ensure_bus_row(primary_cur, bus_id, vehicle_id)
        primary_cur.execute(
            """
            INSERT INTO telemetry.bus_events (time, bus_id, vehicle_id, event_type, payload)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (bus_id, time, event_type) DO NOTHING
            """,
            (ts, bus_id, vehicle_id, event_type, psycopg2.extras.Json(payload)),
        )
        latest_time = ts

    set_watermark(primary_cur, latest_time)
    return len(rows)


def run() -> None:
    primary_conn = connect(PRIMARY_DSN, "primary DB")
    primary_cur = primary_conn.cursor()

    if not check_schema_exists(primary_cur):
        log.error(
            "telemetry.bus_events not found in the primary DB. Apply "
            "bus_enterprise_telemetry_schema.sql to it first (see that "
            "file's own instructions) - this service does not create "
            "the schema itself. Retrying in 10s in case it's mid-setup."
        )
        time_module.sleep(10)
        return run()

    timescale_conn = connect(TIMESCALE_DSN, "TimescaleDB")
    timescale_cur = timescale_conn.cursor()

    total = 0
    while True:
        try:
            n = sync_once(timescale_cur, primary_cur)
            if n:
                total += n
                log.info("Synced %d rows (%d total)", n, total)
        except Exception as exc:
            log.warning("Sync cycle failed (%s) - reconnecting", exc)
            try:
                primary_conn = connect(PRIMARY_DSN, "primary DB")
                primary_cur = primary_conn.cursor()
                timescale_conn = connect(TIMESCALE_DSN, "TimescaleDB")
                timescale_cur = timescale_conn.cursor()
            except Exception:
                pass

        time_module.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    run()
